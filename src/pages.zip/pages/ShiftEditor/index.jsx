import { useEffect } from 'react'
import ShiftTable from './ShiftTable.jsx'
import { LEGEND_SHIFTS, SHIFT_COLORS, SHIFT_LABELS } from '../../constants.js'
import styles from './ShiftEditor.module.css'

export default function ShiftEditor({ year, month, staffStore, shiftStore, rulesStore }) {
  const { staff } = staffStore
  const { getMonthShifts, updateCell, initMonthForStaff, setMonthShifts } = shiftStore
  const { rules } = rulesStore

  const days = new Date(year, month, 0).getDate()

  // 月が変わった時・スタッフが増えた時に未初期化のセルを初期化
  useEffect(() => {
    staff.forEach(s => initMonthForStaff(year, month, s.id, days))
  }, [year, month, staff.length])

  const monthShifts = getMonthShifts(year, month)

  const handleCellChange = (staffId, dayIndex, value) => {
    updateCell(year, month, staffId, dayIndex, value)
  }

  const handleAutoGenerate = () => {
    // TODO: 自動生成エンジン（4-3 で設計済み）を実装
    alert('自動生成エンジンは実装予定です（仕様書 4-3 参照）')
  }

  const handleExcelExport = () => {
    // TODO: SheetJS による Excel 出力
    alert('Excel出力は実装予定です')
  }

  return (
    <div className={styles.page}>
      {/* ── ツールバー ── */}
      <div className={styles.toolbar}>
        <button className="btn btn-primary" onClick={handleAutoGenerate}>
          ⚡ 自動生成
        </button>
        <div className="btn-sep" />
        <button className="btn btn-outline">＋ スタッフ追加</button>
        <div className="btn-sep" />
        <button className="btn btn-success" onClick={handleExcelExport}>
          📥 Excel出力
        </button>
        <button className="btn btn-outline">🖨 PDF出力</button>
      </div>

      {/* ── 凡例 ── */}
      <div className={styles.legend}>
        <span className={styles.legendTitle}>凡例：</span>
        {LEGEND_SHIFTS.map(sh => (
          <div key={sh} className={styles.legendItem}>
            <div
              className={styles.legendChip}
              style={{ background: SHIFT_COLORS[sh] }}
            >
              {sh}
            </div>
            <span>{SHIFT_LABELS[sh]}</span>
          </div>
        ))}
      </div>

      {/* ── テーブル ── */}
      <div className={styles.tableWrapper}>
        <ShiftTable
          year={year}
          month={month}
          days={days}
          staff={staff}
          monthShifts={monthShifts}
          onCellChange={handleCellChange}
        />
      </div>
    </div>
  )
}
